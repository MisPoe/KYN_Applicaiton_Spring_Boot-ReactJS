package com.KYN.KYNApplication.service;

import java.util.List;
import java.util.Optional;

import com.KYN.KYNApplication.dao.Store;


public interface StoreService {
	public List<Store> viewStore();

	public Optional<Store> getStoreId(int sid);
	
}
