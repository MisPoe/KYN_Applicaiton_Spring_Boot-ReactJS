package com.KYN.KYNApplication.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.KYN.KYNApplication.dao.Store;
import com.KYN.KYNApplication.repository.StoreRepository;


@Service
@Transactional
public class StoreServiceImpl implements StoreService{

	@Autowired
	private StoreRepository storeRepo;
	
	@Override
	public List<Store> viewStore() {
		return storeRepo.findAll();
	}

	@Override
	public Optional<Store> getStoreId(int sid) {
		return storeRepo.findById(sid);
	}

}
