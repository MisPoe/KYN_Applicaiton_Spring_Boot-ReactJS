package com.KYN.KYNApplication.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.KYN.KYNApplication.dao.Store;
import com.KYN.KYNApplication.service.StoreService;

	@RestController
	@RequestMapping("/online")
	public class StoreController {
		@Autowired
		private StoreService storeService;
		
		@GetMapping("/view-stores")
	    //@PreAuthorize("hasRole('USER')")
		public List<Store> viewStore(){
			List<Store> stores = storeService.viewStore();
			return stores;
		}
		
		//Search Store ID API 
		@GetMapping("/store/{sid}")
		public Optional<Store> getStoreId(@PathVariable int sid){
			return storeService.getStoreId(sid);
		}
	}

