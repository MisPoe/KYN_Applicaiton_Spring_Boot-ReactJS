package com.KYN.KYNApplication.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.KYN.KYNApplication.dao.Store;


@Repository
public interface StoreRepository extends JpaRepository<Store, Integer>{
	@Query(value = "SELECT s FROM Store s WHERE storeName LIKE '%' || :keyword || '%' " + 
			"OR storeId LIKE '%' || :keyword || '%' " + 
			"OR storeLocation LIKE '%' || :keyword || '%' ")
	public List<Store> searchByKey (@Param("keyword") String keyword);

}