package com.KYN.KYNApplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

import com.KYN.KYNApplication.configuration.AppProperties;

@SpringBootApplication
@EnableConfigurationProperties(AppProperties.class)
public class KynApplication {

	public static void main(String[] args) {
		SpringApplication.run(KynApplication.class, args);
	}

}
